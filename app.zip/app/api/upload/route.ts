// app/api/upload/route.ts:
import type { NextApiRequest, NextApiResponse } from "next";
import formidable from "formidable";
import fs from "fs";
import Papa from "papaparse";

interface Count {
  [key: string]: number;
}

export const config = {
  api: {
    bodyParser: false,
  },
};

const processFile = async (req: NextApiRequest, res: NextApiResponse) => {
  const form = new formidable.IncomingForm();
  console.log("API called");

  form.parse(
    req,
    (err: any, fields: formidable.Fields, files: formidable.Files) => {
      if (err) {
        return res.status(500).json({ error: "File upload error" });
      }

      // Ajustar aqui para lidar com ambos os casos, único arquivo ou múltiplos arquivos
      const fileArray = files.file instanceof Array ? files.file : [files.file];
      if (fileArray.length === 0 || !fileArray[0]) {
        return res.status(400).json({ error: "No files were uploaded" });
      }

      const file = fileArray[0]; // Processa apenas o primeiro arquivo para simplificar

      fs.readFile(
        file.filepath,
        "utf8",
        (err: NodeJS.ErrnoException | null, data: string) => {
          if (err) {
            return res.status(500).json({ error: "Error reading file" });
          }

          Papa.parse(data, {
            complete: (results: any) => {
              const counts: Count = {};
              results.data.forEach((row: string[]) => {
                const value = row[0]; // Assume column 0 for now
                if (counts[value]) {
                  counts[value] += 1;
                } else {
                  counts[value] = 1;
                }
              });

              res.status(200).json(counts);
            },
            header: true,
          });
        }
      );
    }
  );
};

export default processFile;
